package com.mygdx.game.screens;

import static com.mygdx.game.MyGdxGame.SCR_HEIGHT;
import static com.mygdx.game.MyGdxGame.SCR_WIDTH;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.characters.Bird;
import com.mygdx.game.components.MovingBackground;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.components.PointCounter;
import com.mygdx.game.characters.Tube;

import java.io.File;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;


public class ScreenGame implements Screen {

    final int pointCounterMarginTop = 400;
    final int pointCounterMarginRight = 60;
    MyGdxGame myGdxGame;

    Bird bird;
    PointCounter pointCounter;

    int tubeCount = 5;
    Tube[] tubes;
    MovingBackground background;
    int gamePoints;
    boolean isGameOver;

    Clip clip;

    public ScreenGame(MyGdxGame myGdxGame) {
        this.myGdxGame = myGdxGame;

        initTubes();
        posBackground();
        bird = new Bird(0, SCR_HEIGHT / 2,  50, 40);
        pointCounter = new PointCounter(SCR_WIDTH - pointCounterMarginTop, SCR_HEIGHT - pointCounterMarginRight);
    }
    public void posBackground() {
        background = new MovingBackground("backgrounds/game_bg.png", 0, SCR_WIDTH);
        playSound("assets/sounds/sfx_swooshing.wav");
    }
    public void initTubes() {
        tubes = new Tube[tubeCount];
        for (int i = 0; i < tubeCount; i++) {
            tubes[i] = new Tube(tubeCount, i);
        }
    }

    @Override
    public void show() {
        gamePoints = 0;
        isGameOver = false;
        bird.setY(SCR_HEIGHT / 2);
        bird.setX(0);
        posBackground();
        initTubes();
    }

    @Override
    public void render(float delta) {

        if (isGameOver) {
            myGdxGame.screenRestart.gamePoints = gamePoints;
            myGdxGame.setScreen(myGdxGame.screenRestart);
        }

        if (Gdx.input.justTouched()) {
            bird.onClick();
            playSound("assets/sounds/sfx_wing.wav");
        }
        background.move();
        bird.fly();
        if (!bird.isInField()) {
            System.out.println("not in field");
            playSound("assets/sounds/sfx_die.wav");
            isGameOver = true;
        }

        for (Tube tube : tubes) {
            tube.move();
            if (tube.isHit(bird)) {
                System.out.println("hit");
                playSound("assets/sounds/sfx_hit.wav");
                isGameOver = true;
            } else if (tube.needAddPoint(bird)) {
                gamePoints += 1;

                if (gamePoints % 10 == 0) {
                    playSound("assets/sounds/sfx_point.wav");
                }
                tube.setPointReceived();
                System.out.println(gamePoints);
            }
        }

        ScreenUtils.clear(1, 1, 1, 1);
        myGdxGame.camera.update();
        myGdxGame.batch.setProjectionMatrix(myGdxGame.camera.combined);
        myGdxGame.batch.begin();

        background.draw(myGdxGame.batch);
        bird.draw(myGdxGame.batch);

        for (Tube tube : tubes) tube.draw(myGdxGame.batch);

        myGdxGame.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        bird.dispose();
        background.dispose();
        pointCounter.dispose();
        for (int i = 0; i < tubeCount; i++) {
            tubes[i].dispose();
        }
    }

    public void playSound(String filename) {
        try {
            clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File(filename)));
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopSound() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
        }
    }

    public void pauseSound() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
        }
    }

    public void resumeSound() {
        if (clip != null && !clip.isRunning()) {
            clip.start();
        }
    }
}